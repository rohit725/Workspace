import subprocess
import platform
import requests
import psutil
import json
import sys
import os


def system_info():
    """
    This function displays system information.
    """
    dct = {"Python version": sys.version.split('\n'),
           "dist": str(platform.dist()),
           "linux_distribution": linux_distribution(),
           "system": platform.system(),
           "machine": platform.machine(),
           "platform": platform.platform(),
           "uname": platform.uname(),
           "version": platform.version(),
           "mac_version": platform.mac_ver()}
    return dct


def pids_active():
    """
    This function displays all running processes of computer.
    """
    pid_valid = {}
    for proc in psutil.process_iter():
        data = None
        try:
            data = {"pid": proc.pid,
                    "status": proc.status(),
                    "percent_cpu_used": proc.cpu_percent(interval=0.0),
                    "percent_memory_used": proc.memory_percent()}

        except (psutil.ZombieProcess, psutil.AccessDenied, psutil.NoSuchProcess):
            data = None
        if data is not None:
            pid_valid[proc.name()] = data
    return pid_valid


def mem_check(pid):
    """
    This Function checks for memory usages of a current process.
    """
    try:
        rss = psutil.Process(pid).memory_info().rss
        print('current memory used: {rss}'.format(rss=rss))
    except Exception as e:
        print(repr(e) + ' while checking memory usage')


def cpu_percent_check():
    """
    This function returns usage in percent per cpu.
    """
    dct = dict()
    try:
        lst = psutil.cpu_percent(percpu=True)
        overall = psutil.cpu_percent()
        for count, cpu in enumerate(lst):
            cpu_name = "CPU_" + str(count)
            dct[cpu_name] = cpu
        dct["Overall"] = overall
    except Exception as e:
        print(repr(e) + ' while cpu usage')


def virtual_mem_check():
    """
    This function lists stats for RAM.
    """
    dct = dict()
    try:
        stats = psutil.virtual_memory()
        dct = {"total": inMB(stats.total),
               "available": inMB(stats.available),
               "free": inMB(stats.free),
               "used": inMB(stats.used),
               "percent": stats.percent}
    except Exception as e:
        print(repr(e) + ' while checking virtual memory usage')
    return dct


def partitions():
    """
    This function lists the disk partitions installed in the system.
    """
    partitions = list()
    try:
        lst = psutil.disk_partitions()
        for count, disk in enumerate(lst):
            stats = {"device": disk.device,
                     "mountpoint": disk.mountpoint,
                     "fstype": disk.fstype,
                     "opts": disk.opts}
            partitions.append(stats)
    except Exception as e:
        print(repr(e) + ' while checking disk partitions.')
    return stats


def disk_use(path="C:\\"):
    """
    This function lists disk usage for given disk path.
    """
    stats = dict()
    try:
        disk = psutil.disk_usage(path)
        stats = {"total": inGB(disk.total),
                 "used": inGB(disk.used),
                 "free": inGB(disk.free),
                 "percent": disk.percent}
    except Exception as e:
        print(repr(e) + ' while checking disk usage.')
    return stats


def get_service_by_name(name="blu_gunicorn"):
    """
    This function gets a service detail by its name.
    """
    srv = dict()
    try:
        if not psutil.WINDOWS:
            srv["err_mesg"] = "get_service_by_name: Not a windows machine."
            return srv
        srv["normal"] = psutil.win_service_get(name).as_dict()
        srv["Detailed"] = psutil.Process(srv["normal"]["pid"]).as_dict()
        # print("Service check : " + name + " : " + json.dumps(srv))
    except Exception as e:
        print(repr(e) + ' while checking service details.')
    return srv


##########################  Services Functionality Testing ##############################
def test_blu_gunicorn(api_url):
    try:
        response = requests.post(
            url=api_url, data="")
        if response.status_code == 200:
            data = json.loads(response.content)
        else:
            data = {"err_mesg": "django server not working",
                    "status_code": response.status_code}
    except Exception as err:
        print(str(err))
    return data


def test_blu_genie(ip, genie_path, transcript_path):
    p = subprocess.Popen('cmd.exe', stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    cmds = list()
    cmds.append("cd %s" % (genie_path))
    cmds.append(
        "BluGenie.exe \"Invoke-Process -System {} -Command 'Get-SystemInfo' -JobID 7357\"".format(ip))
    for cmd in cmds:
        p.stdin.write((cmd + "\n").encode())
    p.stdin.close()
    p.stdout.read()
    if os.path.exists(transcript_path + "\\7357"):
        with open(transcript_path + "\\7357\\7357.csv", "r") as f:
            data = [w.replace('\x00', '') for w in f.read().splitlines()]
        data = [w for w in data if w]
        print(data)
        data = [w for w in data[-1].split(";") if w]
        return data[-1]
    else:
        return {"err_mesg": "Something wrong with your code or BluGenie not working."}


##########################  Utilities ##############################
def linux_distribution():
    try:
        return platform.linux_distribution()
    except Exception:
        return "N/A"


def inMB(val):
    val = val / (1024 * 1024)
    return str(round(val, 2)) + "MB"


def inGB(val):
    val = val / (1024 * 1024 * 1024)
    return str(round(val, 2)) + "GB"


if __name__ == '__main__':
    # print(pids_active())
    # print(mem_check(pid))
    # print(cpu_percent_check())
    # print(virtual_mem_check())
    # print(partitions())
    # print(disk_use())
    # print(system_info())
    # print(get_service_by_name())
    print(test_blu_genie("192.168.11.32",
                         "C:\\responder", "C:\\responder\\Transcripts"))
