import health_check_lib
import configparser


class HealthCheck:
    def __init__(self):
        pass
