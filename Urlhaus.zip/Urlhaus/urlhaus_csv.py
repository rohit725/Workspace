import requests


def filedownload(url, filename):
    try:
        respons = requests.get(url)
        with open(filename, "w") as f:
            f.write(respons.text)
    except Exception as err:
        print(str(err))


def main():
    filedownload("https://urlhaus.abuse.ch/downloads/csv/", "Urlhaus.csv")
    filedownload("https://urlhaus.abuse.ch/downloads/ids/", "Urlhaus_ids.txt")
    filedownload("https://urlhaus.abuse.ch/downloads/rpz/", "Urlhaus_rpz.txt")
    filedownload("https://urlhaus.abuse.ch/downloads/text/",
                 "Urlhaus_plain_text.txt")
    filedownload("https://urlhaus.abuse.ch/downloads/payloads/",
                 "Urlhaus_payloads.csv")
    filedownload("https://urlhaus.abuse.ch/downloads/urlhaus.ndb",
                 "Urlhaus_ClamAV_signature.txt")


if __name__ == '__main__':
    main()
