Requirements:

	1.  Python: 2.7
	2.  Install py2exe using below command:
		pip install http://sourceforge.net/projects/py2exe/files/latest/download?source=files


If you have some changes in detectRansom.py, run below command to generate executable with new changes:
	python setup.py py2exe