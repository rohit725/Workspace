import sys, os
import hashlib
import json
import time
import collections
import socket
import psutil
import codecs
import traceback

compareLists       = lambda x, y : collections.Counter(x) == collections.Counter(y)

DB_IP     = "" 
DB_NAME   = "" 
DB_USER   = ""
DB_PASSWD = ""
FILE_ID   = 0
conn      = ""
cursor    = ""
UDPSock   = 0

def inMB(val):
    val = val / (1024 * 1024)
    return str(round(val, 2)) + "MB"

def inGB(val):
    val = val / (1024 * 1024 * 1024)
    return str(round(val, 2)) + "GB"
    
def cpu_percent_check():
    """
    This function returns usage in percent per cpu.
    """
    dct = dict()
    try:
        lst = psutil.cpu_percent(percpu=True)
        overall = psutil.cpu_percent()
        for count, cpu in enumerate(lst):
            cpu_name = "CPU_" + str(count)
            dct[cpu_name] = cpu
        dct["Overall"] = overall
    except Exception as e:
        print(repr(e) + ' while cpu usage')

    return dct

def virtual_mem_check():
    """
    This function lists stats for RAM.
    """
    dct = dict()
    try:
        stats = psutil.virtual_memory()
        dct = {"total": inMB(stats.total),
               "available": inMB(stats.available),
               "free": inMB(stats.free),
               "used": inMB(stats.used),
               "percent": stats.percent}
    except Exception as e:
        print(repr(e) + ' while checking virtual memory usage')
    return dct

def getChecksum(file):
    hash_md5 = ''
    try:
        hash_md5 = hashlib.md5()
        with open(file, 'r') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hash_md5.update(chunk)
    except Exception as e:
        print(e)
    return hash_md5.hexdigest()

def checkPermissions(paths):
    dict   = {}
    status = ''
    #print "paths: ", paths
    p = paths
    try:
        if os.path.exists(p):
            dict[p] = []
            if not os.access(p, os.F_OK):
                dict[p].append('NOEXISTS')
            if os.access(p, os.R_OK):
                dict[p].append('READ')
            if os.access(p, os.W_OK):
                dict[p].append('WRITE')
            if os.access(p, os.X_OK):
                dict[p].append('EXECUTE')
            elif os.access(p, os.F_OK) and not (os.access(p, os.R_OK)) and not (os.access(p, os.W_OK)) and not (os.access(p, os.X_OK)):
                dict[p].append("NOACCESS")
    except Exception as e:
        print(e)
    return dict

############################################
### Main
############################################
def main(argv):
    files = []
    #C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\14\15\16\17\18\19\20\21\23\24\25\26\27\28\29\30
    files.append('C:\personal\AllinOne.pdf') 
    files.append('C:\personal\h1.docx')
    files.append('C:\personal\h1.pptx')
    files.append('C:\personal\h1.xlsx')
    files.append('C:\personal\h1.txt')
    files.append('C:\personal\ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc.doc')
    files.append('C:\personal\ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc.docx')	
    files.append('C:\personal\defines.py')
    files.append('C:\personal\h1.bmp')
    files.append('C:\personal\h1.docx')
    files.append('C:\personal\h1.jpg')
    files.append('C:\personal\h2.jpg')
    files.append('C:\personal\h3.jpg')
    files.append('C:\personal\h4.jpg')
    files.append('C:\personal\h1.ppt')
    files.append('C:\personal\h1.pptx')
    files.append('C:\personal\h1.xls')
    files.append('C:\personal\h1.xlsx')
    files.append('C:\personal\h1.txt')
    files.append('C:\personal\wild.wmv')
    files.append('C:\personal\wild.MP3')

    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\AllinOne.pdf') 
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.docx')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.pptx')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.xlsx')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.txt')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\defines.py')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.bmp')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.docx')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.jpg')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h2.jpg')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h3.jpg')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h4.jpg')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.ppt')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.pptx')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.xls')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.xlsx')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\h1.txt')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\wild.wmv')
    files.append('C:\personal\personal2\personal3\personal4\personal5\personal6\personal7\personal8\personal9\p1\p2\p3\p4\p5\p6\p7\p8\p9\p10\p11\p12\p13\\14\\15\\16\\17\\18\\19\\20\\21\\23\\24\\25\\26\\27\\28\\29\\30\\wild.MP3')

    chars = {}
    global DB_IP, DB_NAME, DB_USER, DB_PASSWD, FILE_ID  

    UDPSock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

    for f in files:
        chars[f] = []
        if os.path.exists(f):
            md5 = getChecksum(f)
            #print md5
            result = checkPermissions(f)
            #print result 
            chars[f].append(md5)
            chars[f].append(result[f])

    while(1):
        data = {}
        data["CPU"] = cpu_percent_check()
        data["virtual_memory"] = virtual_mem_check()
        for f in files:
            if os.path.exists(f):
                md5 = getChecksum(f)
                #print 'old md5: ', chars[f][0]
                #print 'new md5: ', md5
                #print 'file   : ', f

                if chars[f][0]!=md5:
                    print 'md5    : ', md5
                    print 'old md5: ', chars[f][0]
                    print 'MD5 changes!'
                    print 'Ransomware Detected!'
                    print 'file   : ', f
                    UDPSock.sendto('1,Ransomware Detected'.encode(),("localhost",9999))
                # else:
                    # print 'md5    : ', md5
                    # print 'No Changes'

                result = checkPermissions(f)
                if result:
                    if compareLists(chars[f][1], result[f]):
                        # print 'File permissions Not changed'
                        pass
                    else:
                        print chars[f][1]
                        print 'File permissions changed'
                        print 'Ransomware Detected!'
                        print 'file   : ', f
                        UDPSock.sendto('1,Ransomware Detected'.encode(),("localhost",9999))
                else:
                    print chars[f][1]
                    print 'File permissions changed'
                    print 'Ransomware Detected!'
                    print 'file   : ', f
                    UDPSock.sendto('1,Ransomware Detected'.encode(),("localhost",9999))
            else:
                print 'File Operation: Rename, Move, Delete'
                print 'Ransomware Detected!'
                print 'file   : ', f
                if chars[f]:
                    print "\t:\t".join(str(v) for v in chars[f])
                UDPSock.sendto('1,Ransomware Detected'.encode(),("localhost",9999))
        cpu_mem_data = codecs.encode('3,' + json.dumps(data), 'utf-8')
        UDPSock.sendto(cpu_mem_data,("localhost",9999))
        time.sleep(5)


if __name__ == '__main__':
    main(sys.argv[1:])
