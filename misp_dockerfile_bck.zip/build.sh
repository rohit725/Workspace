#!/bin/bash
docker rmi harvarditsecurity/misp
docker build \
    --rm=true --force-rm=true \
    --build-arg MYSQL_MISP_PASSWORD=1844di@lG14Solutions\
    --build-arg POSTFIX_RELAY_HOST=localhost \
    --build-arg MISP_FQDN=timisp01.blusapphire.net \
    --build-arg MISP_EMAIL=admin@localhost \
    --build-arg MISP_GPG_PASSWORD=1844di@lG14Solutions\
    -t harvarditsecurity/misp container
